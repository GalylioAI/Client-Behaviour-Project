<?php
/**
 * Configuration for Behaviour Tracker Plugin
 */

return [
    // The URL where the tracking data is sent
    'webhook_url' => 'https://tracker.yatootunisie.tn/webhook',

    // Unique identifier for this website/store (used to distinguish data sources)
    'site_id' => 'tdiscount',

    // SaaS write credentials for this website.
    'write_key' => 'pk_live_e80cfcfa3e559e911f49059b952c190ae1169583d949d78d',
    'server_secret_key' => 'sk_live_af792c04276456ccd2f868a49c4570ed77b4c6e9a2fe2345',

    // Buffer interval in seconds (how often to send batched events)
    // Minimum: 1 second, Recommended: 5-10 seconds
    'buffer_interval' => 3,

    // ========================================
    // MASTER TRACKER SECTION CONTROLS
    // Enable/disable entire tracker sections for isolated testing
    // Set to false to completely disable a section
    // ========================================

    'enabled_sections' => [
        'session_navigation' => true,   // Session & Navigation tracking (session.js, navigation.js)
        'product' => true,              // Product Discovery tracking (product.js)
        'cart' => true,                 // Shopping Cart tracking (cart.js)
        'checkout' => true,             // Checkout & Purchase tracking (checkout.js)
        'account' => true,              // User Account tracking (account.js)
        'search' => true,               // Search & Filters tracking (search.js)
        'marketing' => true,            // Marketing & Promotions tracking (marketing.js)
    ],

    // Optional selector overrides (see config_example.php for detailed docs)
    'selectors' => [
        'click_elements' => [],
        'product_page_containers' => [],
        'product_list_items' => [],
        'cart_rows' => [],
        'cart_quantity_inputs' => [],
        'coupon_forms' => [],
        'shipping_method_inputs' => [],
        'payment_method_inputs' => [],
        'login_forms' => [],
        'register_forms' => [],
        'edit_account_forms' => [],
        'reset_password_forms' => [],
        'search_forms' => [
        'form.products-search',
        ],
        'filter_containers' => [],
        'sort_selects' => [],
        'newsletter_forms' => [],
        'banner_elements' => [],
        'social_share_buttons' => [],
    ],
];

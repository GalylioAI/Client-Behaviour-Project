<?php
/**
 * Configuration for Behaviour Tracker Module
 */

return [
    // The URL where the tracking data is sent
    'webhook_url' => 'https://tracker.yatootunisie.tn/webhook',

    // Unique identifier for this website/store (used to distinguish data sources)
    'site_id' => 'parahouse',

    // SaaS write credentials for this website.
    'write_key' => 'pk_live_your_public_write_key',
    'server_secret_key' => 'sk_live_your_server_secret_key',

    // Buffer interval in seconds (how often to send batched events)
    // Minimum: 1 second, Recommended: 5-10 seconds
    'buffer_interval' => 3,

    // ========================================
    // MASTER TRACKER SECTION CONTROLS
    // Enable/disable entire tracker sections for isolated testing
    // Set to false to completely disable a section
    // ========================================

    'enabled_sections' => [
        'session_navigation' => true,   // Session & Navigation tracking (session.js, navigation.js)
        'product' => true,   // Product Discovery tracking (product.js)
        'cart' => true,   // Shopping Cart tracking (cart.js)
        'checkout' => true,   // Checkout & Purchase tracking (checkout.js)
        'account' => true,   // User Account tracking (account.js)
        'search' => true,   // Search & Filters tracking (search.js)
        'marketing' => true,   // Marketing & Promotions tracking (marketing.js)
    ],

    // Optional custom selectors for non-standard PrestaShop themes.
    // Leave empty to use the built-in defaults.
    'selectors' => [
        'click_elements' => [],
        'product_page_containers' => [],
        'product_list_items' => [],
        'add_to_cart_buttons' => [],
        'cart_quantity_inputs' => [],
        'coupon_forms' => [],
        'shipping_method_inputs' => [],
        'payment_method_inputs' => [],
        'login_forms' => [],
        'register_forms' => [],
        'edit_account_forms' => [],
        'reset_password_forms' => [],
        'search_forms' => [],
        'filter_inputs' => [],
        'sort_selects' => [],
        'newsletter_forms' => [],
        'banner_elements' => [],
        'social_share_buttons' => [],
    ],
];
